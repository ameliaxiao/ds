/**
 * Tianyue Xiao tianyuex@andrew.cmu.edu
 * most codes are taken from Lab 8: Android Lab
 */
package com.example.project4android;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * activity class for the android app
 * @author Amelia
 *
 */
public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        /*
         * reference to this object
         */
        final MainActivity ip = this;
        
        /*
         * add listener
         */
        Button submitButton = (Button)findViewById(R.id.submit);

        
      	// Add a listener to the send button
        submitButton.setOnClickListener(new OnClickListener(){
        	public void onClick(View viewParam) {
        		String searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
        		GetOrder gp = new GetOrder();
        		gp.search(searchTerm, ip); // Done asynchronously in another thread.  It calls ip.ready() in this thread when complete.
        	}
        });
    }
    
    /**
     * This method is called by the GetOrder object when the result is ready.
     * @param result a string representing the result got from the web app
     */
    public void ready(String result) {
    	TextView feedback = (TextView)findViewById(R.id.feedback);
		TextView searchView = (EditText)findViewById(R.id.searchTerm);
		String searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
		if (result != null) {
    		feedback.setText(result);
    	} else {
    		feedback.setText("Sorry, failed to find order of " + searchTerm);
    	}
		searchView.setText("");
    }
}