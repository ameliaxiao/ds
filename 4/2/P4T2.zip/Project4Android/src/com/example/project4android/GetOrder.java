/**
 * Tianyue Xiao tianyuex@andrew.cmu.edu
 */
package com.example.project4android;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

/**
 * class to connect to the web app and do the search
 * @author Amelia
 *
 */
public class GetOrder {
MainActivity ip = null;
	
	/**
	 * public method to get order information. 
	 * @param searchTerm string representing the product id to search
	 * @param ip reference to the object that called this method
	 */
	public void search(String searchTerm, MainActivity ip) {
		this.ip = ip;
		new AsyncFlickrSearch().execute(searchTerm);
	}


	/**
	 * inner class to do network operations in a seperate threads
	 * @author Amelia
	 *
	 */
    private class AsyncFlickrSearch extends AsyncTask<String, Void, String> {
    	/**
    	 * method doInBackground
    	 */
        protected String doInBackground(String... urls) {
            return search(urls[0]);
        }
        /**
         * method onPostExecute, call ready when result is ready
         */
        protected void onPostExecute(String result) {
        	ip.ready(result);
        }

        /**
         * method to link to the web app and do search
         * @param searchTerm product id to search
         * @return string representing the result
         */
        private String search(String searchTerm) {  
        	try{
        		
        		URL url = new URL("http://1-dot-tianyue7777777.appspot.com/project4?id=" + searchTerm);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET"); 
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;

                // read from the urlconnection via the bufferedreader
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                br.close();
                String json = sb.toString();
                JSONObject obj = new JSONObject(json);
                
                StringBuilder result = new StringBuilder();
                result.append(obj.getString("result"));
                result.append("\nWant to try again?");
                return result.toString();
        	} catch(Exception e){
        		return e.toString();
        	}
        	//return null;

        }
        
        
    }
}
