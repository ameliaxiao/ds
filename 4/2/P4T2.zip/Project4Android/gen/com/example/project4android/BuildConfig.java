/** Automatically generated file. DO NOT MODIFY */
package com.example.project4android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}